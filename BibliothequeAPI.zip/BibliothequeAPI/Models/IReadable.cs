namespace BibliothequeAPI.Models;

public interface IReadable
{
    string DisplayInformation();
}