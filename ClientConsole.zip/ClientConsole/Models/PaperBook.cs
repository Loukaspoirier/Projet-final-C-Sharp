namespace ClientConsole.Models;

public class PaperBook : Media
{
    public int PageCount { get; set; }
}
