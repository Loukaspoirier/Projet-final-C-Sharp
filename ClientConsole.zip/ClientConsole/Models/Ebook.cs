namespace ClientConsole.Models;

public class Ebook : Media
{
    public string Format { get; set; } = string.Empty;
}
